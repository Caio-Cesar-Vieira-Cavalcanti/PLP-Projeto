module Main where

main :: IO ()
main = putStrLn "Olá"


