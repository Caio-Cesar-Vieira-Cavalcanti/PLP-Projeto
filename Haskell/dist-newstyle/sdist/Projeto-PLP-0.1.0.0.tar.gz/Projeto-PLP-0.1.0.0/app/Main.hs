module Main where

import System.Random (randomRIO)

main :: IO ()
main = do
  num <- randomRIO (1, 10) :: IO Int  -- Adicionando a anotação de tipo
  putStrLn $ "Número aleatório: " ++ show num


